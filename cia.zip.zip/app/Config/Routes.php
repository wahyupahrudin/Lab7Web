<?php

namespace Config;

$routes = Services::routes();

if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();

// Route Definitions
$routes->get('/', 'Page::home');           // ← diubah/ditambah
$routes->get('/about', 'Page::about');     // ← tambah
$routes->get('/contact', 'Page::contact'); // ← tambah
$routes->get('/faqs', 'Page::faqs');       // ← tambah
$routes->get('/artikel', 'Page::artikel'); // ← tambah

// Additional Routing (biarkan seperti default)
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}